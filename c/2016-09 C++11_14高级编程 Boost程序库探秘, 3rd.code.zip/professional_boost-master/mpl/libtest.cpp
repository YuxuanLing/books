// Copyright (c) 2016
// Author: Chrono Law

extern "C"
{

int so_func1(int x)
{   return x * x;}

int so_func2(int x, int y)
{   return x + y;}

}

