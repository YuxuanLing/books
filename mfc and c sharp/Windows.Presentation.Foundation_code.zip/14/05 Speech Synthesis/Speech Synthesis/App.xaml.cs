using System;
using System.Windows;

namespace Speech_Synthesis
{
    public partial class App : System.Windows.Application
    {

    }
}