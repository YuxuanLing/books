using System;
using System.Windows;

namespace Speech_Recognition
{
    public partial class App : System.Windows.Application
    {

    }
}