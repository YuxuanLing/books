// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__8C61BE5E_0223_4D07_956B_8FE365670934__INCLUDED_)
#define AFX_STDAFX_H__8C61BE5E_0223_4D07_956B_8FE365670934__INCLUDED_

#define WINVER          0x0500
#define _WIN32_WINNT    0x0500
#define _WIN32_IE       0x0501
#define _RICHEDIT_VER   0x0100

#define _ATL_USE_CSTRING
#define _ATL_USE_CSTRING_FLOAT
#define _ATL_USE_DDX_FLOAT

#include <atlbase.h>
#include <atlapp.h>
extern CAppModule _Module;
#include <atlwin.h>
#include <atlcrack.h>
#include <atlframe.h>
#include <atlctrls.h>
#include <atlctrlx.h>
#include <atlmisc.h>
#include <atlddx.h>

#if _ATL_VER < 0x0700
#undef BEGIN_MSG_MAP
#define BEGIN_MSG_MAP(x) BEGIN_MSG_MAP_EX(x)
#endif

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__8C61BE5E_0223_4D07_956B_8FE365670934__INCLUDED_)
