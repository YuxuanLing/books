// aboutdlg.cpp : implementation of the CAboutDlg class
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "resource.h"
#include "aboutdlg.h"

LRESULT CAboutDlg::OnInitDialog(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
{
LPCTSTR szURL = _T("http://www.codeproject.com/");

    // Remember to set the extended styles before the static ctrls are
    // subclassed (by DoDataExchange).
    m_wndBoldLinkWithHover.SetHyperLinkExtendedStyle ( HLINK_USETAGSBOLD|HLINK_UNDERLINEHOVER );
    m_wndLinkWithTags.SetHyperLinkExtendedStyle ( HLINK_USETAGS );
    m_wndBoldLinkWithTags.SetHyperLinkExtendedStyle ( HLINK_USETAGSBOLD );

    DlgResize_Init ( true, false );
    CenterWindow(GetParent());
    DoDataExchange();

    // Set the URLs that the links will navigate to.
    m_wndBoldLinkWithHover.SetHyperLink ( szURL );
    m_wndLinkWithTags.SetHyperLink ( szURL );
    m_wndBoldLinkWithTags.SetHyperLink ( szURL );

    // Change the tooltip for the first link. 1 is the tool ID that CHyperLink
    // assigns to itself when it calls AddTool().  I didn't have any luck
    // updating the text by calling m_tip.UpdateTipText(), but it does work
    // using this code (the same code that CHyperLink::Init() uses).
    m_wndBoldLinkWithHover.m_tip.AddTool ( m_wndBoldLinkWithHover, _T("Clickety!"),
                                           &m_wndBoldLinkWithHover.m_rcLink, 1 );

    return TRUE;
}

LRESULT CAboutDlg::OnCloseCmd(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
    EndDialog(wID);
    return 0;
}
