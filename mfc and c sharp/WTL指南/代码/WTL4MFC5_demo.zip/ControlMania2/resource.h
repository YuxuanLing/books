//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ControlMania2.rc
//
#define IDC_ABOUT                       3
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDD_MAINDLG                     129
#define IDB_ALYSON                      201
#define IDB_ALYSON_IMGLIST              202
#define IDC_TREE                        1000
#define IDC_ALYSON_BTN                  1001
#define IDC_ALYSON_BMPBTN               1002
#define IDC_CP_LINK                     1003
#define IDC_CHECK_LIST                  1004
#define IDC_FAV_SEASON                  1005
#define IDC_RELATIONSHIP_TREE           1006
#define IDC_SEASON_LABEL                1007
#define IDC_LINK1                       1008
#define IDC_LINK2                       1009
#define IDC_LINK3                       1010
#define IDC_LABEL                       1011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        202
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
