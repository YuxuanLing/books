// ControlMania2.h
