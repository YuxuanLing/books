// CtrlClasses.cpp: implementation of the CCtrlClasses class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "CtrlClasses.h"
#include "resource.h"

//////////////////////////////////////////////////////////////////////

LRESULT CBuffyTreeCtrl::OnItemExpanding ( NMHDR* phdr )
{
NMTREEVIEW* pnmtv = (NMTREEVIEW*) phdr;

    if ( pnmtv->action & TVE_COLLAPSE )
        return TRUE;    // don't allow it
    else
        return FALSE;   // allow it
}

DWORD CBuffyTreeCtrl::OnPrePaint(int idCtrl, LPNMCUSTOMDRAW lpNMCD)
{
    // Get notifications for every tree item being drawn.
    return CDRF_NOTIFYITEMDRAW;
}

DWORD CBuffyTreeCtrl::OnItemPrePaint(int idCtrl, LPNMCUSTOMDRAW lpNMCD)
{
NMTVCUSTOMDRAW* pnmtv = (NMTVCUSTOMDRAW*) lpNMCD;

    switch ( lpNMCD->lItemlParam )
        {
        case 1:
            pnmtv->clrText = RGB(0,128,0);
        break;

        case 2:
            pnmtv->clrText = RGB(255,0,0);
        break;

        case 3:
            pnmtv->clrText = RGB(0,0,255);
        break;

        case 4:
            pnmtv->clrText = RGB(196,196,196);
        break;
        }

    return CDRF_DODEFAULT;
}

//////////////////////////////////////////////////////////////////////

CODButtonImpl::CODButtonImpl()
{
    m_bmp.LoadBitmap ( IDB_ALYSON );
}

void CODButtonImpl::DrawItem ( LPDRAWITEMSTRUCT lpdis )
{
CDCHandle dc = lpdis->hDC;
CDC dcMem;

    dcMem.CreateCompatibleDC ( dc );
    dc.SaveDC();
    dcMem.SaveDC();

    // Draw the button's background, red if it has the focus, blue if not.
    if ( lpdis->itemState & ODS_FOCUS ) 
        dc.FillSolidRect ( &lpdis->rcItem, RGB(255,0,0) );
    else
        dc.FillSolidRect ( &lpdis->rcItem, RGB(0,0,255) );

    // Draw the bitmap in the top-left, or offset by 1 pixel if the button
    // is clicked.
    dcMem.SelectBitmap ( m_bmp );

    if ( lpdis->itemState & ODS_SELECTED ) 
        dc.BitBlt ( 1, 1, 80, 80, dcMem, 0, 0, SRCCOPY );
    else
        dc.BitBlt ( 0, 0, 80, 80, dcMem, 0, 0, SRCCOPY );

    dcMem.RestoreDC(-1);
    dc.RestoreDC(-1);
}