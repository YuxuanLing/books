// maindlg.h : interface of the CMainDlg class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINDLG_H__3CE121B6_C376_4836_8D73_963B51D6B8BF__INCLUDED_)
#define AFX_MAINDLG_H__3CE121B6_C376_4836_8D73_963B51D6B8BF__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "CtrlClasses.h"

static const int SEASON_MIN = 1, SEASON_MAX = 7;

class CMainDlg : public CDialogImpl<CMainDlg>, public CUpdateUI<CMainDlg>,
                 public CMessageFilter, public CIdleHandler,
                 public CWinDataExchange<CMainDlg>,
                 public CCustomDraw<CMainDlg>,
                 public CDialogResize<CMainDlg>
{
public:
    enum { IDD = IDD_MAINDLG };

    CMainDlg() : m_nSeason(3)
    {
    }

    BEGIN_MSG_MAP(CMainDlg)
        MSG_WM_INITDIALOG(OnInitDialog)
        COMMAND_ID_HANDLER_EX(IDOK, OnOK)
        COMMAND_ID_HANDLER_EX(IDCANCEL, OnCancel)
        COMMAND_ID_HANDLER_EX(IDC_ALYSON_BTN, OnAlysonODBtn)
        COMMAND_ID_HANDLER_EX(IDC_ABOUT, OnAbout)
        CHAIN_MSG_MAP(CCustomDraw<CMainDlg>)
        CHAIN_MSG_MAP(CDialogResize<CMainDlg>)
        REFLECT_NOTIFICATIONS()
    END_MSG_MAP()

    BEGIN_UPDATE_UI_MAP(CMainDlg)
        UPDATE_ELEMENT(IDC_ALYSON_BMPBTN, UPDUI_CHILDWINDOW)
    END_UPDATE_UI_MAP()

    BEGIN_DDX_MAP(CMainDlg)
        DDX_CONTROL(IDC_TREE, m_wndTree)
        DDX_CONTROL(IDC_ALYSON_BTN, m_wndODBtn)
        DDX_CONTROL(IDC_CP_LINK, m_wndLink)
        DDX_CONTROL(IDC_CHECK_LIST, m_wndChkList)
        DDX_INT_RANGE(IDC_FAV_SEASON, m_nSeason, SEASON_MIN, SEASON_MAX)
        DDX_CONTROL(IDC_RELATIONSHIP_TREE, m_wndRelationshipTree)
    END_DDX_MAP()

    BEGIN_DLGRESIZE_MAP(CMainDlg)
        DLGRESIZE_CONTROL(IDOK, DLSZ_MOVE_X)
        DLGRESIZE_CONTROL(IDCANCEL, DLSZ_MOVE_X)
        DLGRESIZE_CONTROL(IDC_ABOUT, DLSZ_MOVE_X)
        DLGRESIZE_CONTROL(IDC_TREE, DLSZ_SIZE_X)
        DLGRESIZE_CONTROL(IDC_CP_LINK, DLSZ_MOVE_X)
        DLGRESIZE_CONTROL(IDC_CHECK_LIST, DLSZ_SIZE_X)
        DLGRESIZE_CONTROL(IDC_SEASON_LABEL, DLSZ_MOVE_X)
        DLGRESIZE_CONTROL(IDC_FAV_SEASON, DLSZ_MOVE_X)
        DLGRESIZE_CONTROL(IDC_RELATIONSHIP_TREE, DLSZ_SIZE_X|DLSZ_SIZE_Y)
    END_DLGRESIZE_MAP()

    BOOL PreTranslateMessage(MSG* pMsg);
    BOOL OnIdle();

    LRESULT OnInitDialog(HWND hwndFocus, LPARAM lParam);
    void    OnOK(UINT uCode, int nID, HWND hwndCtrl);
    void    OnCancel(UINT uCode, int nID, HWND hwndCtrl);
    void    OnAbout(UINT uCode, int nID, HWND hwndCtrl);
    void    OnAlysonODBtn(UINT uCode, int nID, HWND hwndCtrl);

    DWORD OnPrePaint ( int idCtrl, NMCUSTOMDRAW* pnmcd );
    DWORD OnItemPrePaint ( int idCtrl, NMCUSTOMDRAW* pnmcd );

    void CloseDialog(int nVal);

    // DDX overrides
    void OnDataValidateError(UINT nCtrlID, BOOL bSave, _XData& data);

protected:
    // DDX vars
    CBuffyTreeCtrl      m_wndTree;
    CODButtonImpl       m_wndODBtn;
    CHyperLink          m_wndLink;
    CMyCheckListCtrl    m_wndChkList;
    int                 m_nSeason;
    CTreeViewCtrlExImpl m_wndRelationshipTree;

    // other controls
    CBitmapButton  m_wndBmpBtn;
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINDLG_H__3CE121B6_C376_4836_8D73_963B51D6B8BF__INCLUDED_)
