// maindlg.cpp : implementation of the CMainDlg class
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "resource.h"
#include "aboutdlg.h"
#include "maindlg.h"

BOOL CMainDlg::PreTranslateMessage(MSG* pMsg)
{
    return IsDialogMessage(pMsg);
}

BOOL CMainDlg::OnIdle()
{
    UIUpdateChildWindows();
    return FALSE;
}

LRESULT CMainDlg::OnInitDialog(HWND hwndFocus, LPARAM lParam)
{
    // Init dialog resizing
    DlgResize_Init();

    // center the dialog on the screen
    CenterWindow();

    // set icons
    HICON hIcon = (HICON)::LoadImage(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDR_MAINFRAME), 
        IMAGE_ICON, ::GetSystemMetrics(SM_CXICON), ::GetSystemMetrics(SM_CYICON), LR_DEFAULTCOLOR);
    SetIcon(hIcon, TRUE);
    HICON hIconSmall = (HICON)::LoadImage(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDR_MAINFRAME), 
        IMAGE_ICON, ::GetSystemMetrics(SM_CXSMICON), ::GetSystemMetrics(SM_CYSMICON), LR_DEFAULTCOLOR);
    SetIcon(hIconSmall, FALSE);

    // register object for message filtering and idle updates
    CMessageLoop* pLoop = _Module.GetMessageLoop();
    ATLASSERT(pLoop != NULL);
    pLoop->AddMessageFilter(this);
    pLoop->AddIdleHandler(this);

    UIAddChildWindowContainer(m_hWnd);

    // Hook up controls & variables
    DoDataExchange(false);

    // Fill in the tree
HTREEITEM htiSummers, htiHank, htiDawn;

    htiSummers = m_wndTree.InsertItem ( _T("Summers"), TVI_ROOT, TVI_LAST );
    m_wndTree.InsertItem ( _T("Joyce"), htiSummers, TVI_LAST );
    htiHank = m_wndTree.InsertItem ( _T("Hank"), htiSummers, TVI_LAST );
    m_wndTree.InsertItem ( _T("Buffy"), htiHank, TVI_LAST );
    htiDawn = m_wndTree.InsertItem ( _T("Dawn"), htiHank, TVI_LAST );
    m_wndTree.SetItemData ( htiDawn, 1 );

HTREEITEM htiVamps = m_wndTree.InsertItem ( _T("Vamps"), TVI_ROOT, htiSummers );
HTREEITEM htiMaster, htiDarla, htiAngel, htiDru, htiSpike;

    htiMaster = m_wndTree.InsertItem ( _T("The Master"), htiVamps, TVI_LAST );
    htiDarla = m_wndTree.InsertItem ( _T("Darla"), htiMaster, TVI_LAST );
    htiAngel = m_wndTree.InsertItem ( _T("Angel"), htiDarla, TVI_LAST );
    htiDru = m_wndTree.InsertItem ( _T("Drusilla"), htiAngel, TVI_LAST );
    htiSpike = m_wndTree.InsertItem ( _T("Spike"), htiDru, TVI_LAST );
    
    m_wndTree.SetItemData ( htiAngel, 3 );
    m_wndTree.SetItemData ( htiSpike, 3 );
    m_wndTree.SetItemData ( htiMaster, 4 );
    m_wndTree.SetItemData ( htiDarla, 4 );
    m_wndTree.SetItemData ( htiDru, 2 );

    m_wndTree.Expand ( htiSummers );
    m_wndTree.Expand ( htiHank );

    // Set up the bitmap button
CImageList iml;

    iml.CreateFromImage ( IDB_ALYSON_IMGLIST, 81, 1, CLR_NONE, IMAGE_BITMAP, 
                          LR_CREATEDIBSECTION );

    m_wndBmpBtn.SubclassWindow ( GetDlgItem(IDC_ALYSON_BMPBTN) );
    m_wndBmpBtn.SetToolTipText ( _T("Alyson") );
    m_wndBmpBtn.SetImageList ( iml );
    m_wndBmpBtn.SetImages ( 0, 1, 2, 3 );

    // NOTE: CBitmapButton owns the image list now, no need to free it here.

    // Set up the hyperlink
    m_wndLink.SetHyperLink ( _T("http://www.codeproject.com/") );
            
    // Set up the check list ctrl.
    m_wndChkList.InsertColumn ( 0, _T("Scoobies"), LVCFMT_LEFT, 100, 0 );

    m_wndChkList.InsertItem ( 0, _T("Willow") );
    m_wndChkList.InsertItem ( 1, _T("Buffy") );
    m_wndChkList.InsertItem ( 2, _T("Giles") );

    m_wndChkList.SetColumnWidth ( 0, LVSCW_AUTOSIZE_USEHEADER );

    // Here's how you use CTreeItems with a CTreeViewCtrlEx
CTreeItem tiBuffy, tiWillow, tiTara;

    // Insert a "Buffy" item, then add children to it. AddTail() adds an item
    // at the end of the existing group of child nodes. 0 is the image index,
    // which is ignored since this tree has no image list.
    tiBuffy = m_wndRelationshipTree.InsertItem ( _T("Buffy"), TVI_ROOT, TVI_LAST );
    tiBuffy.AddTail ( _T("Angel"), 0 );
    tiBuffy.AddTail ( _T("Parker"), 0 );
    tiBuffy.AddTail ( _T("Riley"), 0 );
    tiBuffy.AddTail ( _T("Spike"), 0 );

    // Now insert a "Willow" node, but insert children with AddHead(). This 
    // adds to the beginning of the current group of child nodes.
    tiWillow = m_wndRelationshipTree.InsertItem ( _T("Willow"), TVI_ROOT, tiBuffy );
    tiWillow.AddHead ( _T("Kennedy"), 0 );
    tiTara = tiWillow.AddHead ( _T("Tara"), 0 );
    tiWillow.AddHead ( _T("Oz"), 0 );

    tiWillow.Expand();

    // Just to demonstrate another CTreeItem method, this sets the item data
    // for the Tara node.
    tiTara.SetData ( 42 );

    return TRUE;
}

void CMainDlg::OnOK ( UINT uCode, int nID, HWND hwndCtrl )
{
    if ( !DoDataExchange(true) )
        return;

    CloseDialog(nID);
}

void CMainDlg::OnCancel ( UINT uCode, int nID, HWND hwndCtrl )
{
    CloseDialog(nID);
}

void CMainDlg::OnAbout ( UINT uCode, int nID, HWND hwndCtrl )
{
CAboutDlg dlg;

    dlg.DoModal();
}

void CMainDlg::CloseDialog(int nVal)
{
    DestroyWindow();
    PostQuitMessage(nVal);
}

void CMainDlg::OnAlysonODBtn ( UINT uCode, int nID, HWND hwndCtrl )
{
    UIEnable ( IDC_ALYSON_BMPBTN, !m_wndBmpBtn.IsWindowEnabled() );
}

DWORD CMainDlg::OnPrePaint ( int idCtrl, NMCUSTOMDRAW* pnmcd )
{
    if ( pnmcd->hdr.idFrom != IDC_CHECK_LIST )
        {
        SetMsgHandled(false);
        return 0;
        }
    else
        {
        return CDRF_NOTIFYITEMDRAW;
        }
}

DWORD CMainDlg::OnItemPrePaint ( int idCtrl, NMCUSTOMDRAW* pnmcd )
{
NMLVCUSTOMDRAW* pnmlv = (NMLVCUSTOMDRAW*) pnmcd;

    if ( pnmcd->hdr.idFrom != IDC_CHECK_LIST )
        {
        SetMsgHandled(false);
        return 0;
        }

    switch ( pnmlv->nmcd.dwItemSpec )
        {
        case 0: pnmlv->clrText = RGB(255,0,0); break;
        case 1: pnmlv->clrText = RGB(0,255,0); break;
        case 2: pnmlv->clrText = RGB(0,0,255); break;
        }

    return CDRF_DODEFAULT;
}

void CMainDlg::OnDataValidateError ( UINT nCtrlID, BOOL bSave, _XData& data )
{
CString sMsg;

    sMsg.Format ( _T("Enter a number between %d and %d"),
                  data.intData.nMin, data.intData.nMax );

    MessageBox ( sMsg, _T("ControlMania2"), MB_ICONEXCLAMATION );
	
    GotoDlgCtrl ( GetDlgItem(nCtrlID) );
}
