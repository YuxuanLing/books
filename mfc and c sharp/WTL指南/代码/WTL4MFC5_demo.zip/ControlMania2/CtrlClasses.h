// CtrlClasses.h: interface for the CCtrlClasses class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CTRLCLASSES_H__B443039D_D24B_42EF_BC58_181E734C9BA9__INCLUDED_)
#define AFX_CTRLCLASSES_H__B443039D_D24B_42EF_BC58_181E734C9BA9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// A tree control that doesn't allow nodes to be collapsed, and has custom
// draw handlers.
class CBuffyTreeCtrl : public CWindowImpl<CBuffyTreeCtrl, CTreeViewCtrl>,
                       public CCustomDraw<CBuffyTreeCtrl>
{
public:
    BEGIN_MSG_MAP(CBuffyTreeCtrl)
        REFLECTED_NOTIFY_CODE_HANDLER_EX(TVN_ITEMEXPANDING, OnItemExpanding)
        CHAIN_MSG_MAP_ALT(CCustomDraw<CBuffyTreeCtrl>, 1)
        DEFAULT_REFLECTION_HANDLER()
    END_MSG_MAP()

    LRESULT OnItemExpanding ( NMHDR* phdr );

    DWORD OnPrePaint(int idCtrl, LPNMCUSTOMDRAW lpNMCD);
    DWORD OnItemPrePaint(int idCtrl, LPNMCUSTOMDRAW lpNMCD);
};

// A button that has an owner draw handler.
class CODButtonImpl : public CWindowImpl<CODButtonImpl, CButton>,
                      public COwnerDraw<CODButtonImpl>
{
public:
    CODButtonImpl();

    BEGIN_MSG_MAP(CODButtonImpl)
        CHAIN_MSG_MAP_ALT(COwnerDraw<CODButtonImpl>, 1)
        DEFAULT_REFLECTION_HANDLER()
    END_MSG_MAP()

    void DrawItem ( LPDRAWITEMSTRUCT lpdis );

protected:
    CBitmap m_bmp;
};


// Custom styles for our check list ctrl. Note that when subclassing an existing
// control, only the list extended styles (LVS_EX_*) are used, so that's why
// the first two params here are 0.
typedef CCheckListViewCtrlImplTraits<
    0, 0, LVS_EX_CHECKBOXES | LVS_EX_GRIDLINES | LVS_EX_UNDERLINEHOT |
            LVS_EX_ONECLICKACTIVATE> CMyCheckListTraits;

class CMyCheckListCtrl : 
    public CCheckListViewCtrlImpl<CMyCheckListCtrl, CListViewCtrl, CMyCheckListTraits>
{
private:
    typedef CCheckListViewCtrlImpl<CMyCheckListCtrl, CListViewCtrl, CMyCheckListTraits> baseClass;
public:
	DECLARE_WND_SUPERCLASS(_T("WTL_CheckListView"), GetWndClassName())

    BEGIN_MSG_MAP(CMyCheckListCtrl)
        CHAIN_MSG_MAP(baseClass)
    END_MSG_MAP()
};

// CTreeViewCtrlEx impl class for use in DDX
class CTreeViewCtrlExImpl : public CWindowImpl<CTreeViewCtrlExImpl, CTreeViewCtrlEx >
{
    DECLARE_EMPTY_MSG_MAP()
};

#endif // !defined(AFX_CTRLCLASSES_H__B443039D_D24B_42EF_BC58_181E734C9BA9__INCLUDED_)
