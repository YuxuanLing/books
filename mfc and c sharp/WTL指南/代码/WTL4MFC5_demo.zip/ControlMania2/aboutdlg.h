// aboutdlg.h : interface of the CAboutDlg class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_ABOUTDLG_H__6B3114C2_EC78_4C88_B549_B140077D2E25__INCLUDED_)
#define AFX_ABOUTDLG_H__6B3114C2_EC78_4C88_B549_B140077D2E25__INCLUDED_

class CAboutDlg : public CDialogImpl<CAboutDlg>,
                  public CWinDataExchange<CAboutDlg>,
                  public CDialogResize<CAboutDlg>
{
public:
    enum { IDD = IDD_ABOUTBOX };

    BEGIN_MSG_MAP(CAboutDlg)
        MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
        COMMAND_ID_HANDLER(IDOK, OnCloseCmd)
        COMMAND_ID_HANDLER(IDCANCEL, OnCloseCmd)
        CHAIN_MSG_MAP(CDialogResize<CAboutDlg>)
    END_MSG_MAP()

    BEGIN_DDX_MAP(CAboutDlg)
        DDX_CONTROL(IDC_LINK1, m_wndBoldLinkWithHover)
        DDX_CONTROL(IDC_LINK2, m_wndLinkWithTags)
        DDX_CONTROL(IDC_LINK3, m_wndBoldLinkWithTags)
    END_DDX_MAP();

    BEGIN_DLGRESIZE_MAP(CAboutDlg)
        DLGRESIZE_CONTROL(IDOK, DLSZ_MOVE_X)
        DLGRESIZE_CONTROL(IDC_LABEL, DLSZ_SIZE_X)
        DLGRESIZE_CONTROL(IDC_LINK1, DLSZ_SIZE_X)
        DLGRESIZE_CONTROL(IDC_LINK2, DLSZ_SIZE_X)
        DLGRESIZE_CONTROL(IDC_LINK3, DLSZ_SIZE_X)
    END_DLGRESIZE_MAP()

    LRESULT OnInitDialog(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/);
    LRESULT OnCloseCmd(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/);

protected:
    CHyperLink m_wndBoldLinkWithHover, m_wndLinkWithTags, m_wndBoldLinkWithTags;
};

#endif // !defined(AFX_ABOUTDLG_H__6B3114C2_EC78_4C88_B549_B140077D2E25__INCLUDED_)
