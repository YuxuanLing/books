// DropTargetImpl.cpp: implementation of the CDropTargetImpl class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "DropTargetImpl.h"
