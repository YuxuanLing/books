//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by WTLClipSpy.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDS_LIST_HEADER                 129
#define IDS_PANE_CONTAINER_TEXT         129
#define IDS_READING_DATA_MSG            130
#define IDS_CLOSEBTN_TOOLTIP            131
#define IDS_COLHDR_FORMAT               132
#define IDS_COLHDR_DATASIZE             133
#define IDS_DATA_UNAVAILABLE            134
#define IDS_DATA_NOT_DISPLAYABLE        135
#define IDC_READ_CLIPBOARD              32772
#define IDC_CLEAR_CLIPBOARD             32773
#define IDC_SHOW_BOTTOM_PANE            32774
#define IDC_HIDE_BOTTOM_PANE            32775
#define IDC_LOCK_SPLITTERS              32776
#define IDC_UNLOCK_PANES                32777
#define IDC_PATTERN_BARS                32778
#define IDC_NORMAL_BARS                 32779
#define IDC_COLOR_CONTAINERS            32780
#define IDC_NORMAL_CONTAINERS           32781

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32782
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
