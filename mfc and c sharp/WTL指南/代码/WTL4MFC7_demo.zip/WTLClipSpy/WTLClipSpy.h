// WTLClipSpy.h
