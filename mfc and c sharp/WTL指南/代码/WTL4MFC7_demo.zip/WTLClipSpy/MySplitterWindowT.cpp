// MySplitterWindowT.cpp: implementation of the CMySplitterWindowT class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "MySplitterWindowT.h"

