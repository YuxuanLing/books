// MainFrm.cpp : implmentation of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "resource.h"

#include "aboutdlg.h"
#include "WTLClock3View.h"
#include "MainFrm.h"

BOOL CMainFrame::PreTranslateMessage(MSG* pMsg)
{
    if(CFrameWindowImpl<CMainFrame>::PreTranslateMessage(pMsg))
        return TRUE;

    return m_view.PreTranslateMessage(pMsg);
}

BOOL CMainFrame::OnIdle()
{
    // Check the current Caps Lock state, and if it is on, show the CAPS
    // indicator in pane 2 of the status bar.
    if ( GetKeyState(VK_CAPITAL) & 1 )
        UISetText ( 2, CString(LPCTSTR(IDPANE_CAPS_INDICATOR)) );
    else
        UISetText ( 2, _T("") );

    UIUpdateToolBar();
    UIUpdateStatusBar();
    // BUG:: Popup menu items don't get their text set by CUpdateUI when the 
    //       call to UIUpdateStatusBar() is present.  If the above call is left in,
    //       the Start/Stop menu item under the Clock menu doesn't have its
    //       text changed.  Remove it and the menu updating works again (but 
    //       of course you lose the status bar updating).

    return FALSE;
}

LRESULT CMainFrame::OnCreate(LPCREATESTRUCT lpcs)
{
    HWND hWndToolBar = CreateSimpleToolBarCtrl(m_hWnd, IDR_MAINFRAME, FALSE, ATL_SIMPLE_TOOLBAR_PANE_STYLE);

    CreateSimpleReBar(ATL_SIMPLE_REBAR_NOBORDER_STYLE);
    AddSimpleReBarBand(hWndToolBar);

    // Turn off & processing in the tooltip control. This is necessary so that 
    // an & in tooltip text is displayed properly.
CToolTipCtrl wndTip = (HWND) ::SendMessage ( hWndToolBar, TB_GETTOOLTIPS, 0, 0 );

    wndTip.ModifyStyle ( 0, TTS_NOPREFIX );

    // Create the multipane status bar and pass its handle to CUpdateUI.
    m_hWndStatusBar = m_wndStatusBar.Create ( *this );
    UIAddStatusBar ( m_hWndStatusBar );
    
    // Create the status bar panes.
int anPanes[] = { ID_DEFAULT_PANE, IDPANE_STATUS, IDPANE_CAPS_INDICATOR };

    m_wndStatusBar.SetPanes ( anPanes, 3, false );

    // Set the initial text for the clock status pane.
    UISetText ( 1, _T("Running") );

    m_hWndClient = m_view.Create(m_hWnd, rcDefault, NULL, WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | WS_CLIPCHILDREN, WS_EX_CLIENTEDGE);

    UIAddToolBar(hWndToolBar);
    UISetCheck(ID_VIEW_TOOLBAR, 1);
    UISetCheck(ID_VIEW_STATUS_BAR, 1);

    // register object for message filtering and idle updates
    CMessageLoop* pLoop = _Module.GetMessageLoop();
    ATLASSERT(pLoop != NULL);
    pLoop->AddMessageFilter(this);
    pLoop->AddIdleHandler(this);

    return 0;
}

LRESULT CMainFrame::OnFileExit(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
    PostMessage(WM_CLOSE);
    return 0;
}

LRESULT CMainFrame::OnViewToolBar(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
    static BOOL bVisible = TRUE;    // initially visible
    bVisible = !bVisible;
    CReBarCtrl rebar = m_hWndToolBar;
    int nBandIndex = rebar.IdToIndex(ATL_IDW_BAND_FIRST);   // toolbar is first 1st band
    rebar.ShowBand(nBandIndex, bVisible);
    UISetCheck(ID_VIEW_TOOLBAR, bVisible);
    UpdateLayout();
    return 0;
}

LRESULT CMainFrame::OnViewStatusBar(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
    BOOL bVisible = !::IsWindowVisible(m_hWndStatusBar);
    ::ShowWindow(m_hWndStatusBar, bVisible ? SW_SHOWNOACTIVATE : SW_HIDE);
    UISetCheck(ID_VIEW_STATUS_BAR, bVisible);
    UpdateLayout();
    return 0;
}

LRESULT CMainFrame::OnAppAbout(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
CAboutDlg dlg;

    dlg.DoModal();
    return 0;
}

void CMainFrame::OnCPColors ( UINT uCode, int nID, HWND hwncCtrl )
{
    m_view.SetColors ( RGB(0,0,0), RGB(255,153,0) );
}

void CMainFrame::OnBWColors ( UINT uCode, int nID, HWND hwncCtrl )
{
    m_view.SetColors ( RGB(255,255,255), RGB(0,0,0) );
}

void CMainFrame::OnStartStopClock ( UINT uCode, int nID, HWND hwncCtrl )
{
// NOTE: The calls to set the text of IDC_START_STOP look like they have no
// effect. See the comments in OnIdle() for an explanation.

    if ( m_view.IsClockRunning() )
        {
        m_view.StopClock();
        UISetText ( IDC_START_STOP, _T("&Start") );
        UISetText ( 1, _T("Stopped") );
        }
    else
        {
        m_view.StartClock();
        UISetText ( IDC_START_STOP, _T("&Stop") );
        UISetText ( 1, _T("Running") );
        }
}
