//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by WTLClock3.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDPANE_STATUS                   129
#define IDPANE_CAPS_INDICATOR           130
#define IDC_CP_COLORS                   32772
#define IDC_BW_COLORS                   32773
#define IDC_START_STOP                  32774

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
