// WTLClock3View.cpp : implementation of the CWTLClock3View class
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "resource.h"

#include "WTLClock3View.h"

BOOL CWTLClock3View::PreTranslateMessage(MSG* pMsg)
{
    pMsg;
    return FALSE;
}

LRESULT CWTLClock3View::OnPaint(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
{
CPaintDC dc(m_hWnd);
CRect    rc;
CString  sTime;

    // Get our window's client area.
    GetClientRect ( rc );

    // Build the string to show in the window.
    if ( m_bClockRunning )
        {
        sTime.Format ( _T("The time is %d:%02d:%02d"), 
                       m_stLastTime.wHour, m_stLastTime.wMinute, m_stLastTime.wSecond );
        }
    else
        {
        sTime.Format ( _T("Clock stopped on %d:%02d:%02d"), 
                       m_stLastTime.wHour, m_stLastTime.wMinute, m_stLastTime.wSecond );
        }

    // Set up the DC and draw the text.
    dc.SaveDC();
    
    dc.SetBkColor ( m_crBkgnd );
    dc.SetTextColor ( m_crText );
    dc.ExtTextOut ( 0, 0, ETO_OPAQUE, rc, sTime, sTime.GetLength(), NULL );

    // Restore the DC.
    dc.RestoreDC(-1);
    return 0;
}
