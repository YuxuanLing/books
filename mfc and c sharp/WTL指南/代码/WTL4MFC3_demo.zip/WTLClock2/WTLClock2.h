// WTLClock2.h
