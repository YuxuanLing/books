// WTLClock2View.h : interface of the CWTLClock2View class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_WTLCLOCK2VIEW_H__63C0EBA7_8484_45B2_90AA_599A9C1CA0A2__INCLUDED_)
#define AFX_WTLCLOCK2VIEW_H__63C0EBA7_8484_45B2_90AA_599A9C1CA0A2__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CWTLClock2View : public CWindowImpl<CWTLClock2View>
{
public:
    CWTLClock2View() : m_bClockRunning(true), m_crText(RGB(0,0,0)),
                       m_crBkgnd(RGB(255,153,0))
    { }

    DECLARE_WND_CLASS(NULL)

    BOOL PreTranslateMessage(MSG* pMsg);

    BEGIN_MSG_MAP(CWTLClock2View)
        MESSAGE_HANDLER(WM_PAINT, OnPaint)
        MSG_WM_CREATE(OnCreate)
        MSG_WM_DESTROY(OnDestroy)
        MSG_WM_TIMER(OnTimer)
        MSG_WM_ERASEBKGND(OnEraseBkgnd)
    END_MSG_MAP()

    LRESULT OnCreate ( LPCREATESTRUCT lpcs )
    {
        GetLocalTime ( &m_stLastTime );
        SetTimer ( 1, 1000 );
        SetMsgHandled(false);
        return 0;
    }

    void OnDestroy()
    {
        KillTimer(1);
        SetMsgHandled(false);
    }

    void OnTimer ( UINT uTimerID, TIMERPROC pTimerProc )
    {
        if ( 1 != uTimerID )
            SetMsgHandled(false);
        else
            {
            // If the clock is running, get the current time & redraw our
            // window so the new time appears.
            if ( m_bClockRunning )
                {
                GetLocalTime ( &m_stLastTime );
                RedrawWindow();
                }
            }
    }

    LRESULT OnEraseBkgnd ( HDC hdc )
    {
        return 1;   // OnPaint will draw the whole window
    }

    LRESULT OnPaint(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/);

    void StartClock() 
    { 
        m_bClockRunning = true; 
        GetLocalTime ( &m_stLastTime );
        RedrawWindow();
    }

    void StopClock() 
    { 
        m_bClockRunning = false; 
        RedrawWindow();
    }

    void SetColors ( const COLORREF crText, const COLORREF crBkgnd )
    {
        m_crText = crText;
        m_crBkgnd = crBkgnd;
        RedrawWindow();
    }

    bool IsClockRunning() const 
        { return m_bClockRunning; }

protected:
    SYSTEMTIME m_stLastTime;
    bool       m_bClockRunning;
    COLORREF   m_crText, m_crBkgnd;
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WTLCLOCK2VIEW_H__63C0EBA7_8484_45B2_90AA_599A9C1CA0A2__INCLUDED_)
