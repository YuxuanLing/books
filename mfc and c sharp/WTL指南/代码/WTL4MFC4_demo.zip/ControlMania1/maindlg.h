// maindlg.h : interface of the CMainDlg class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINDLG_H__D6D5C625_D717_44F9_BF3E_E1C789DEE419__INCLUDED_)
#define AFX_MAINDLG_H__D6D5C625_D717_44F9_BF3E_E1C789DEE419__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CMainDlg : public CDialogImpl<CMainDlg>,
                 public CWinDataExchange<CMainDlg>
{
public:
    enum { IDD = IDD_MAINDLG };

    CMainDlg();
    ~CMainDlg();

#if _ATL_VER < 0x0700
    BEGIN_MSG_MAP(CMainDlg)
#else
    // BUG:: You need to use BEGIN_MSG_MAP_EX in VC7 when you use a
    // CContainedWindowT variable that routes messages to an ALT_MSG_MAP
    // section like we do here.
    BEGIN_MSG_MAP_EX(CMainDlg)
#endif
        MSG_WM_INITDIALOG(OnInitDialog)
        COMMAND_ID_HANDLER_EX(ID_APP_ABOUT, OnAppAbout)
        COMMAND_ID_HANDLER_EX(IDOK, OnOK)
        COMMAND_ID_HANDLER_EX(IDCANCEL, OnCancel)
        NOTIFY_HANDLER_EX(IDC_LIST, LVN_ITEMCHANGED, OnListItemchanged)
        REFLECT_NOTIFICATIONS()
    ALT_MSG_MAP(1)
        MSG_WM_SETCURSOR(OnSetCursor_OK)
    ALT_MSG_MAP(2)
        MSG_WM_SETCURSOR(OnSetCursor_Exit)
    ALT_MSG_MAP(3)
        // no msg handlers for the list control
    END_MSG_MAP()

    // NOTE: Comment out the DDX_INT and DDX_UINT lines if you want to see
    // DDX_FLOAT handle input like "3.14". The decimal point makes DDX_INT/UINT
    // error because it's not a number.
    BEGIN_DDX_MAP(CMainDlg)
        DDX_CONTROL(IDC_EDIT, m_wndEdit)
        DDX_TEXT(IDC_EDIT, m_sEditContents)
        //DDX_INT(IDC_EDIT, m_nEditNumber)
        //DDX_UINT(IDC_EDIT, m_uEditUint)
        DDX_FLOAT(IDC_EDIT, m_fEditFloat)
        DDX_FLOAT(IDC_EDIT, m_dEditDouble)
        DDX_CHECK(IDC_SHOW_MSG, m_bShowMsg)
        DDX_CONTROL(IDC_TREE, m_wndTree)
    END_DDX_MAP()

    LRESULT OnInitDialog(HWND hwndFocus, LPARAM lParam);
    void    OnAppAbout(UINT uCode, int nID, HWND hWndCtl);
    void    OnOK(UINT uCode, int nID, HWND hWndCtl);
    void    OnCancel(UINT uCode, int nID, HWND hWndCtl);
    LRESULT OnListItemchanged(NMHDR* phdr);

    LRESULT OnSetCursor_OK(HWND hwndCtrl, UINT uHitTest, UINT uMouseMsg);
    LRESULT OnSetCursor_Exit(HWND hwndCtrl, UINT uHitTest, UINT uMouseMsg);

    // DDX override
    void OnDataExchangeError(UINT nCtrlID, BOOL bSave);

protected:
    CListViewCtrl m_wndList;
    CContainedWindow m_wndOKBtn, m_wndExitBtn;
    CContainedWindowT<CListViewCtrl> m_wndListccw;
    CButtonImpl      m_wndAboutBtn;
    CEditImpl        m_wndEdit;
    CBuffyTreeCtrl   m_wndTree;

    // DDX variables
    CString     m_sEditContents;
    int         m_nEditNumber;
    UINT        m_uEditUint;
    float       m_fEditFloat;
    double      m_dEditDouble;
    bool        m_bShowMsg;
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINDLG_H__D6D5C625_D717_44F9_BF3E_E1C789DEE419__INCLUDED_)
