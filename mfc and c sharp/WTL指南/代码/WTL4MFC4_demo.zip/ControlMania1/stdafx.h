// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__23C0632F_31F8_4C36_A4F2_D0D437F981B2__INCLUDED_)
#define AFX_STDAFX_H__23C0632F_31F8_4C36_A4F2_D0D437F981B2__INCLUDED_

// Change these values to use different versions
#define WINVER          0x0500
#define _WIN32_WINNT    0x0500
#define _WIN32_IE       0x0501
#define _RICHEDIT_VER   0x0100

#define _ATL_USE_CSTRING
#define _ATL_USE_CSTRING_FLOAT
#define _ATL_USE_DDX_FLOAT

#include <atlbase.h>
#include <atlapp.h>
extern CAppModule _Module;
#include <atlwin.h>
#include <atlcrack.h>
#include <atlctrls.h>
#include <atlmisc.h>
#include <atlddx.h>

#if _ATL_VER < 0x0700
#undef BEGIN_MSG_MAP
#define BEGIN_MSG_MAP(x) BEGIN_MSG_MAP_EX(x)
#endif


// CButtonImpl - CWindowImpl-derived class that implements a button.  We need a
// class like this to do subclassing or DDX.
class CButtonImpl : public CWindowImpl<CButtonImpl, CButton>
{
    BEGIN_MSG_MAP(CButtonImpl)
        MSG_WM_SETCURSOR(OnSetCursor)
    END_MSG_MAP()

    LRESULT OnSetCursor(HWND hwndCtrl, UINT uHitTest, UINT uMouseMsg)
    {
    static HCURSOR hcur = LoadCursor ( NULL, IDC_SIZEALL );

        if ( NULL != hcur )
            {
            SetCursor ( hcur );
            return TRUE;
            }
        else
            {
            SetMsgHandled(false);
            return FALSE;
            }
    }
};


// CEditImpl - CWindowImpl-derived class that implements a button.  We need a
// class like this to do subclassing or DDX.
class CEditImpl : public CWindowImpl<CEditImpl, CEdit>
{
    BEGIN_MSG_MAP(CEditImpl)
        MSG_WM_CONTEXTMENU(OnContextMenu)
    END_MSG_MAP()

    void OnContextMenu ( HWND hwndCtrl, CPoint ptClick )
    {
        MessageBox("Edit control handled WM_CONTEXTMENU");
    }
};


// A tree control that doesn't allow nodes to be collapsed, and has custom
// draw handlers.
class CBuffyTreeCtrl : public CWindowImpl<CBuffyTreeCtrl, CTreeViewCtrl>,
                       public CCustomDraw<CBuffyTreeCtrl>
{
public:
    BEGIN_MSG_MAP(CBuffyTreeCtrl)
        REFLECTED_NOTIFY_CODE_HANDLER_EX(TVN_ITEMEXPANDING, OnItemExpanding)
        DEFAULT_REFLECTION_HANDLER()
    END_MSG_MAP()

    LRESULT OnItemExpanding ( NMHDR* phdr )
    {
    NMTREEVIEW* pnmtv = (NMTREEVIEW*) phdr;
        
        if ( pnmtv->action & TVE_COLLAPSE )
            return TRUE;    // don't allow it
        else
            return FALSE;   // allow it
    }
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__23C0632F_31F8_4C36_A4F2_D0D437F981B2__INCLUDED_)
