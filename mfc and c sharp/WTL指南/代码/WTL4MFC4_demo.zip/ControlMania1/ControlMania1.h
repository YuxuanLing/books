// ControlMania1.h
