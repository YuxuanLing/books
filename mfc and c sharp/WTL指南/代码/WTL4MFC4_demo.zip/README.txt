This code accompanied the article:
  WTL for MFC Programmers, Part IV - Dialogs and Controls
available at this URL:
  http://www.codeproject.com/wtl/wtl4mfc4.asp
written by:
  Michael Dunn (acidhelm@gmail.com)
Release date:
  December 20, 2005

If you're looking for the license terms that this code is released under,
see the file "LICENSE.txt".

This demo code runs unchanged on VC 6 and VC 7.1, just open the project
file that corresponds to your version of VC (.dsw or .sln).

If you run into problems with building or using the code, please check the
article's web page (listed above) to see if there are any updates to the article
or the code. Also, check the article's discussion forum (located at the bottom
of the article's web page) to see if your problem has already been found and
solved. If not, post a message to the article's forum, and I'll see what I can
do for you.
I prefer that you post to the article's forum, instead of emailing me directly,
so that your question can be visible to everyone. Also, if we end up solving
your problem, the solution will also be visible and will help others.
