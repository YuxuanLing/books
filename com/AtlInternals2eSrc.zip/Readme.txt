The Table of Contents
Foreword 
Preface 
Chapter 01 -- Hello ATL 
Chapter 02 -- Strings and Text 
Chapter 03 -- Smart Types 
Chapter 04 -- Objects 
Chapter 05 -- Servers 
Chapter 06 -- Interface Maps 
Chapter 07 -- Persistence 
Chapter 08 -- Enumeration 
Chapter 09 -- Connection Points 
Chapter 10 -- Windowing 
Chapter 11 -- Controls 
Chapter 12 -- Control Containment 
Chapter 13 -- Hello ATL Server 
Chapter 14 -- ATL Server Internals 
Appendix A -- C++ Templates 
Appendix B -- ATL Classes and Headers 
Appendix C -- Moving To ATL8 
Appendix D -- Attributed ATL 
Index 
