// MathService.cpp : Implementation of WinMain

#include "stdafx.h"
#include "resource.h"

// The module attribute causes WinMain to be automatically implemented for you
[ module(SERVICE, uuid = "{95C54D4C-17F8-43A2-96EE-F0DAB71F06D9}", 
		 name = "MathService", 
		 helpstring = "MathService 1.0 Type Library", 
		 resource_name="IDS_SERVICENAME") ];
