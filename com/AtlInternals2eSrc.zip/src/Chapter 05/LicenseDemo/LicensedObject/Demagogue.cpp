// Demagogue.cpp : Implementation of CDemagogue

#include "stdafx.h"
#include "Demagogue.h"


// CDemagogue

