// CoCalc.cpp : Implementation of CCalc

#include "stdafx.h"
#include "CoCalc.h"


// CCalc

