//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by atlduck.rc
//
#define IDS_PROJNAME                    100
#define IDR_Atlduck                     100
#define IDR_DUCKDOER                    101
#define IDD_DUCKDOERDLG                 202
#define IDC_LISTCONNPTS                 208
#define IDC_QUACK                       209
#define IDC_PADDLE                      210
#define IDC_FLAP                        211
#define IDC_WALK                        212

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
