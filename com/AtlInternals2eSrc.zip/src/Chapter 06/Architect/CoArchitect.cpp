// CoArchitect.cpp : Implementation of CArchitect

#include "stdafx.h"
#include "CoArchitect.h"


// CArchitect


STDMETHODIMP CArchitect::Draw(void)
{
	// TODO: Add your implementation code here

	return S_OK;
}
