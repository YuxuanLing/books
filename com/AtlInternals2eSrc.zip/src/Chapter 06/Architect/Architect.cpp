// Architect.cpp : Implementation of DLL Exports.

#include "stdafx.h"
#include "resource.h"

// The module attribute causes DllMain, DllRegisterServer and DllUnregisterServer to be automatically implemented for you
[ module(dll, uuid = "{9D24326D-0AF5-4C27-9383-23209D877055}", 
		 name = "Architect", 
		 helpstring = "Architect 1.0 Type Library",
		 resource_name = "IDR_ARCHITECT") ];
