// AcePowell.cpp : Implementation of DLL Exports.

#include "stdafx.h"
#include "resource.h"

// The module attribute causes DllMain, DllRegisterServer and DllUnregisterServer to be automatically implemented for you
[ module(dll, uuid = "{A6B18BCB-04CA-4629-A23A-82FAB4E86F29}", 
		 name = "AcePowell", 
		 helpstring = "AcePowell 1.0 Type Library",
		 resource_name = "IDR_ACEPOWELL") ];
