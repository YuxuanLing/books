// stdafx.cpp : source file that includes just the standard includes
// BullsEyeControl.pch will be the pre-compiled header
// stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"

#define INITGUID
#include <guiddef.h>

#include "Designer.h"

// {0D22FF22-28CC-11d2-ABDD-00A0C9C8E50D}
const GUID CATID_ATLINTERNALS_SAMPLES = 
{ 0xd22ff22, 0x28cc, 0x11d2, { 0xab, 0xdd, 0x0, 0xa0, 0xc9, 0xc8, 0xe5, 0xd } };

const IID IID_ICategorizeProperties =
{ 0x4d07fc10, 0xf931, 0x11ce, { 0xb0, 0x01, 0x00, 0xaa, 0x00, 0x68, 0x84, 0xe5}};


