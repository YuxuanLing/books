//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by BullsEyeControl.rc
//
#define IDS_PROJNAME                    100
#define IDR_BULLSEYECONTROL             101
#define IDB_BULLSEYE                    102
#define IDR_BULLSEYE                    103
#define IDD_ABOUTDLG                    104
#define IDS_TITLEBullsEyePropPage       107
#define IDS_HELPFILEBullsEyePropPage    108
#define IDS_DOCSTRINGBullsEyePropPage   109
#define IDR_BULLSEYEPROPPAGE            110
#define IDD_BULLSEYEPROPPAGE            111
#define IDS_COMDROPTARGET_DESC          139
#define IDS_BULLSEYEDROPSOURCE_DESC     142
#define IDI_BULLSEYE                    201
#define IDC_SPIN1                       202
#define IDC_RINGCOUNT                   203
#define IDR_WAVE1                       204
#define IDC_BEEP                        204
#define IDR_ARROW                       204
#define IDC_ENABLED                     205
#define IDC_TRANSPARENT                 206
#define IDR_REGISTRY1                   207
#define IDS_INVALIDRINGCOUNT            512
#define IDS_INVALIDRINGLESSTHANONE      513
#define IDS_INVALIDRINGNUMBER           514

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        209
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
