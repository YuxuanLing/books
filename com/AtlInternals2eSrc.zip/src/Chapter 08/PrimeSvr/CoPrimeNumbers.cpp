// CoPrimeNumbers.cpp : Implementation of CPrimeNumbers

#include "stdafx.h"
#include "CoPrimeNumbers.h"


// CPrimeNumbers

