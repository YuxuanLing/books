#pragma once

static const wchar_t *FORUM_CONNECTION_STRING = L"Provider=SQLOLEDB.1;User ID=ForumUser;Password=pwd;Persist Security Info=False;Initial Catalog=Forums;Data Source=.\\SQLEXPRESS";
