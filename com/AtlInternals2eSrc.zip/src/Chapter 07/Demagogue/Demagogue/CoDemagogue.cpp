// CoDemagogue.cpp : Implementation of CDemagogue

#include "stdafx.h"
#include "CoDemagogue.h"


// CDemagogue

