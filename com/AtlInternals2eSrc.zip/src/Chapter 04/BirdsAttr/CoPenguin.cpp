// CoPenguin.cpp : Implementation of CPenguin

#include "stdafx.h"
#include "CoPenguin.h"


// CPenguin


STDMETHODIMP CPenguin::get_Wingspan(LONG* pVal)
{
	// TODO: Add your implementation code here

	return S_OK;
}

STDMETHODIMP CPenguin::put_Wingspan(LONG newVal)
{
	// TODO: Add your implementation code here

	return S_OK;
}

STDMETHODIMP CPenguin::get_Name(BSTR* pVal)
{
	// TODO: Add your implementation code here

	return S_OK;
}

STDMETHODIMP CPenguin::put_Name(BSTR newVal)
{
	// TODO: Add your implementation code here

	return S_OK;
}

STDMETHODIMP CPenguin::Fly(void)
{
	// TODO: Add your implementation code here

	return S_OK;
}

STDMETHODIMP CPenguin::StraightenTie(void)
{
	// TODO: Add your implementation code here

	return S_OK;
}
