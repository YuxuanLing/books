// CoCalc.cpp : Implementation of CCalc

#include "stdafx.h"
#include "CoCalc.h"


// CCalc


STDMETHODIMP CCalc::Add(DOUBLE Op1, DOUBLE Op2, DOUBLE* Result)
{
	return S_OK;
}
