// Advert.cpp : Implementation of CAdvert

#include "stdafx.h"
#include "Advert.h"


// CAdvert
