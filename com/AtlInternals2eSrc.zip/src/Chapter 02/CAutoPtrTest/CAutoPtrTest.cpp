// CAutoPtrTest.cpp : Implementation of DLL Exports.

#include "stdafx.h"
#include "resource.h"

// The module attribute causes DllMain, DllRegisterServer and DllUnregisterServer to be automatically implemented for you
[ module(dll, uuid = "{86CC14CA-8320-4DBE-AE2E-9DC4C86E35CC}", 
		 name = "CAutoPtrTest", 
		 helpstring = "CAutoPtrTest 1.0 Type Library",
		 resource_name = "IDR_CAUTOPTRTEST") ];
