struct args {
  long	arg1;
  long	arg2;
};

struct result {
  long	sum;
};
